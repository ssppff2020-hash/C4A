#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lesson_check.py — 教学设计质量校验器（确定性脚本）
隶属技能：lesson-design-assistant
用途：对一份已生成的教学设计 Markdown 做 7 项机械校验，输出评分与逐项改进建议。
     把"教案好不好"里可以客观判断的部分（结构齐不齐、目标可不可测、时间对不对得上、
     目标-评估有没有对齐）从"凭感觉"变成"可复现"，让技能真正满足「可验证」。
纯标准库，无第三方依赖。

用法示例：
    python lesson_check.py 教案.md
    python lesson_check.py 教案.md --json
    python lesson_check.py 教案.md --silent     # 只在失败时输出

退出码：0 全部通过（可有告警）；1 存在 ❌ 项；2 文件读取失败。

校验项（与 references/design_framework.yaml 的 check_rules 对应）：
  C1 八段结构完整      C2 目标动词可测量    C3 环节时长合计=课时
  C4 目标-评估对齐     C5 评估含过程/结果    C6 学情假设已标注
  C7 自查清单存在
"""

import argparse
import json
import re
import sys
from pathlib import Path

# ---------- 规则数据（单文件自包含，保证零依赖可运行） ----------

PASS, WARN, FAIL = "pass", "warn", "fail"
MARK = {PASS: "✅", WARN: "⚠️", FAIL: "❌"}

# 八段：key -> (显示名, 标题关键词候选)
SECTIONS = [
    ("basic",     "基本信息",   ["基本信息", "课程基本信息"]),
    ("students",  "学情分析",   ["学情分析", "学习者分析", "学情"]),
    ("objectives", "教学目标",  ["教学目标", "学习目标", "目标"]),
    ("focus",     "教学重难点", ["教学重难点", "重难点", "教学重点", "重点难点"]),
    ("phases",    "教学环节",   ["教学环节", "教学过程", "环节设计", "教学活动"]),
    ("methods",   "教学方法",   ["教学方法", "方法与手段", "教学策略"]),
    ("assessment", "教学评估",  ["教学评估", "教学评价", "评价方式", "考核方式"]),
    ("reflection", "课后反思",  ["课后反思", "教学反思", "反思与迭代", "反思"]),
]

# 布鲁姆可测量动词（知识/能力/素养）
MEASURABLE_VERBS = [
    # 记忆 / 理解
    "列出", "复述", "识别", "说出", "写出", "默写", "标出", "列举",
    "解释", "举例", "总结", "概括", "区分", "比较", "描述", "说明", "归纳", "阐述",
    # 应用 / 分析 / 评价 / 创造
    "应用", "使用", "演示", "操作", "计算", "实现", "编写", "求解", "绘制", "配置",
    "分析", "拆解", "归类", "推断", "诊断", "对比", "辨别", "定位",
    "评价", "判断", "评估", "论证", "推荐", "反思", "审查", "校验",
    "设计", "构建", "创作", "规划", "提出", "开发", "撰写", "制定", "完成",
    # 态度 / 价值
    "认同", "重视", "遵守", "主动", "坚持", "养成", "树立", "形成", "内化", "体会",
]

# 不可观测动词：若某条目标"只"含这些词而无任何可测量动词，则判失败
VAGUE_VERBS = ["了解", "掌握", "熟悉", "知道", "理解", "学习", "认识", "懂得", "明白"]

DEFAULT_DURATION_HINT = "课时长度"

# 占位符：命中说明该小节仍是骨架、未真正填写
PLACEHOLDER_TOKENS = ["（待补充）", "(待补充)", "（待填）", "待补充", "TODO", "待填",
                      "……", "（分钟）", "（学生已掌握什么？）", "（学生能做什么？）",
                      "（兴趣点/痛点？）", "（学困生/学优生支持策略）"]
# 小节有效正文低于该字数即视为"未填充"
MIN_SECTION_CHARS = 15
PHASE_NAMES = ["导入", "新授", "讲授", "互动", "练习", "应用", "总结", "小结",
               "任务发布", "演示", "实操", "检查", "拓展", "作业"]


# ---------- 解析工具 ----------

def read_text(path: Path) -> str:
    for enc in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    return path.read_text(encoding="utf-8", errors="replace")


def split_sections(text: str):
    """返回 {标题: 正文} —— 以 Markdown 标题（#/##/###）切分。"""
    blocks, title, buf = {}, None, []
    for line in text.splitlines():
        m = re.match(r"^\s{0,3}(#{1,4})\s+(.*?)\s*$", line)
        if m:
            if title is not None:
                blocks[title] = "\n".join(buf)
            title, buf = m.group(2).strip(), []
        else:
            buf.append(line)
    if title is not None:
        blocks[title] = "\n".join(buf)
    return blocks


def find_section(blocks, keywords):
    """按关键词找小节正文，返回 (标题, 正文) 或 (None, "")。"""
    for title, body in blocks.items():
        clean = re.sub(r"[^一-鿿A-Za-z]", "", title)
        for kw in keywords:
            if kw in clean:
                return title, body
    return None, ""


def parse_duration_minutes(text: str):
    """从基本信息里取课时长度（分钟）。支持 '45 分钟' / '2 学时' / '90min'。"""
    m = re.search(r"(课时|课时长度|时长|授课时长)\s*[:：|]?\s*(\d+(?:\.\d+)?)\s*(分钟|min|学时|课时)?",
                  text)
    if not m:
        return None
    val = float(m.group(2))
    unit = m.group(3) or "分钟"
    if unit in ("学时", "课时"):
        val *= 45  # 1 学时按 45 分钟折算
    return int(round(val))


def parse_phase_table(text: str):
    """从环节表格里提取 [(环节名, 分钟)]。"""
    out = []
    for line in text.splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 2:
            continue
        name = re.sub(r"[^一-鿿A-Za-z]", "", cells[0])
        if not name or name in ("环节", "环节名称", "教学环节"):
            continue
        if not any(k in name for k in PHASE_NAMES):
            continue
        # 找到该行第一个纯数字单元格（可带 ' 分' / '分钟'）
        for c in cells[1:4]:
            m = re.match(r"^(\d+(?:\.\d+)?)\s*(?:分钟|分|min|')?$", c)
            if m:
                out.append((name, float(m.group(1))))
                break
    return out


# ---------- 未填充检测（防止"空骨架拿高分"） ----------

def _real_chars(body: str) -> int:
    """去掉 Markdown 表格线/符号/空白后，统计真实正文字符数。"""
    s = re.sub(r"[|\-—–:：*\s#>\[\]()（）]", "", body)
    for tok in PLACEHOLDER_TOKENS:
        s = s.replace(tok, "")
    return len(s)


def find_unfilled(blocks):
    """返回仍未填充的小节名列表（正文过短，或含占位符）。"""
    unfilled = []
    for _, label, kws in SECTIONS:
        title, body = find_section(blocks, kws)
        if title is None:
            continue  # 缺失由 C1 单独报
        has_ph = any(tok in body for tok in PLACEHOLDER_TOKENS)
        if has_ph or _real_chars(body) < MIN_SECTION_CHARS:
            unfilled.append(label)
    return unfilled


# ---------- 七项校验 ----------

def check_structure(blocks):
    missing = [label for _, label, kws in SECTIONS if find_section(blocks, kws)[0] is None]
    unfilled = find_unfilled(blocks)

    if missing:
        msg = f"缺少 {len(missing)} 个必需小节：{'、'.join(missing)}"
        tips = [f"补齐小节：{'、'.join(missing)}"]
        return (FAIL if len(missing) > 2 else WARN), msg, tips

    # 结构齐全但大量未填充 —— 空骨架不算合格
    if len(unfilled) >= 3:
        return FAIL, (f"小节齐全但 {len(unfilled)} 段仍是占位骨架未填写："
                      f"{'、'.join(unfilled)}"), \
               [f"填充以下小节的实质内容：{'、'.join(unfilled)}"]
    if unfilled:
        return WARN, f"以下小节内容过少或仍含占位符：{'、'.join(unfilled)}", \
               [f"补充实质内容：{'、'.join(unfilled)}"]
    return PASS, "8 段结构齐全且均已填充", []


def check_objectives(blocks):
    title, body = find_section(blocks, ["教学目标", "学习目标"])
    if not body.strip():
        return FAIL, "未找到教学目标小节", ["补充教学目标（知识/能力/素养三类）"]
    # 取 bullet 行作为目标条目
    items = [l.strip(" -*•\t") for l in body.splitlines()
             if re.match(r"^\s*([-*•]|\d+[.、])\s*\S", l) and len(l.strip()) > 6]
    if not items:
        items = [l.strip() for l in body.splitlines() if len(l.strip()) > 6]
    if not items:
        return FAIL, "教学目标小节为空", ["补充可测量的教学目标"]

    vague_only, no_verb = [], []
    for it in items:
        has_measurable = any(v in it for v in MEASURABLE_VERBS)
        has_vague = any(v in it for v in VAGUE_VERBS)
        if not has_measurable:
            (vague_only if has_vague else no_verb).append(it[:28])
    bad = vague_only + no_verb
    if not bad:
        return PASS, f"{len(items)} 条目标均含可测量动词", []
    detail = "；".join(bad[:3]) + ("…" if len(bad) > 3 else "")
    tips = ["把『了解/掌握/熟悉』改写为可观测动词（说出/解释/实现/设计/评估…）"]
    if len(bad) == len(items):
        return FAIL, f"{len(bad)}/{len(items)} 条目标无可测量动词：{detail}", tips
    return WARN, f"{len(bad)}/{len(items)} 条目标无可测量动词：{detail}", tips


def check_duration(blocks, full_text):
    _, phases_body = find_section(blocks, ["教学环节", "教学过程", "环节设计"])
    phases = parse_phase_table(phases_body or full_text)
    if not phases:
        return WARN, "未从环节表解析出时长", ["环节表请使用『| 环节 | 时长 | 教师活动 | 学生活动 | 设计意图 |』格式并填分钟数"]
    total = sum(p[1] for p in phases)
    declared = parse_duration_minutes(full_text)
    if declared is None:
        return WARN, f"环节合计 {total:g} 分钟，但未找到声明课时", ["在基本信息中写明『课时长度：N 分钟』"]
    diff = abs(total - declared)
    if diff <= 0.5:
        return PASS, f"环节合计 {total:g} 分钟 = 课时 {declared} 分钟", []
    return FAIL, f"环节合计 {total:g} 分钟 ≠ 课时 {declared} 分钟（差 {diff:g}）", [
        f"调整环节时长使合计等于 {declared} 分钟"]


def check_alignment(blocks):
    """目标类别是否在评估小节中被覆盖。"""
    _, obj_body = find_section(blocks, ["教学目标", "学习目标"])
    _, assess_body = find_section(blocks, ["教学评估", "教学评价", "评价方式"])
    if not assess_body.strip():
        return FAIL, "未找到教学评估小节，无法判断对齐", ["补充教学评估并标注与目标的对应关系"]
    cats = [c for c in ("知识", "能力", "素养") if c in obj_body]
    if not cats:
        cats = ["知识", "能力"]
    hit = [c for c in cats if c in assess_body]
    miss = [c for c in cats if c not in assess_body]
    if not miss:
        return PASS, f"评估覆盖全部目标类别（{'、'.join(cats)}）", []
    return WARN, f"评估未标注覆盖：{'、'.join(miss)}", [f"在评估小节写明{'、'.join(miss)}目标由哪项评估验证"]


def check_assessment_types(blocks):
    _, body = find_section(blocks, ["教学评估", "教学评价", "评价方式"])
    if not body.strip():
        return FAIL, "未找到教学评估小节", ["补充过程性与结果性评估"]
    has_f = any(k in body for k in ("过程性", "形成性", "课堂提问", "随堂", "互评"))
    has_s = any(k in body for k in ("结果性", "总结性", "终结性", "作业", "测验", "考试", "项目"))
    if has_f and has_s:
        return PASS, "含过程性评估与结果性评估", []
    miss = ("过程性" if not has_f else "") + ("结果性" if not has_s else "")
    return WARN, f"缺少{miss}评估", [f"补充{miss}评估方式与观测点"]


def check_assumptions(blocks):
    _, body = find_section(blocks, ["学情分析", "学习者分析"])
    if not body.strip():
        return WARN, "未找到学情分析小节", ["补充知识基础/能力水平/动机/差异化四维分析"]
    guessed = any(k in body for k in ("假设", "推测", "预计", "可能", "有待", "不确定"))
    marked = "【假设】" in body or "[假设]" in body or "（假设）" in body
    if guessed and not marked:
        return WARN, "学情含推测性表述但未标注【假设】", ["对未经前测验证的学情判断标注【假设】，提示教师课前核实"]
    return PASS, "学情推测已标注或均为事实描述", []


def check_selfcheck(blocks, full_text):
    ok = "自查清单" in full_text or re.search(r"- \[[ x]\]", full_text) is not None
    return (PASS, "含自查清单", []) if ok else (WARN, "未附自查清单", ["在文末附 4 项自查清单（结构/可测量/对齐/覆盖）"])


# ---------- 主流程 ----------

def run_checks(path: Path):
    text = read_text(path)
    blocks = split_sections(text)
    results = [
        ("C1 结构完整", *check_structure(blocks)),
        ("C2 目标可测量", *check_objectives(blocks)),
        ("C3 时长一致", *check_duration(blocks, text)),
        ("C4 目标-评估对齐", *check_alignment(blocks)),
        ("C5 评估双类型", *check_assessment_types(blocks)),
        ("C6 学情假设标注", *check_assumptions(blocks)),
        ("C7 自查清单", *check_selfcheck(blocks, text)),
    ]
    score = sum(100 if r[1] == PASS else 60 if r[1] == WARN else 0 for r in results) / len(results)

    # 全局门控：未填充的小节越多，总分上限越低，避免"空骨架拿高分"误导使用者
    unfilled = find_unfilled(blocks)
    cap = 40 if len(unfilled) >= 3 else 80 if unfilled else 100
    if score > cap:
        score = float(cap)
    return results, score


def render(path, results, score):
    n_fail = sum(1 for r in results if r[1] == FAIL)
    lines = [f"# 教学设计质量校验报告", "",
             f"- 文件：`{Path(path).name}`",
             f"- 得分：**{score:.0f} / 100**",
             f"- 结果：{'通过 ✅' if n_fail == 0 else f'存在 {n_fail} 项 FAIL ❌'}", "",
             "| 校验项 | 结果 | 说明 |", "|--------|------|------|"]
    for name, status, msg, _ in results:
        lines.append(f"| {name} | {MARK[status]} | {msg} |")
    tips = [t for _, _, _, ts in results for t in ts]
    if tips:
        lines += ["", "## 改进建议"]
        lines += [f"{i}. {t}" for i, t in enumerate(dict.fromkeys(tips), 1)]
    lines += ["", "---", "*本报告由 lesson-check 确定性脚本生成，仅校验可机械判断的结构性指标；"
                  "内容质量、学情真实性、思政融入等仍需教师人工把关。*"]
    return "\n".join(lines)


def _force_utf8_stdout():
    """Windows 控制台默认 GBK，输出 ✅/⚠️/❌ 会崩。尽量切成 UTF-8，失败则降级。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def main() -> int:
    _force_utf8_stdout()
    ap = argparse.ArgumentParser(description="教学设计质量校验器（8 段式教案）")
    ap.add_argument("file", help="待校验的教学设计 Markdown 文件")
    ap.add_argument("--json", action="store_true", help="输出 JSON（便于自动化）")
    ap.add_argument("--silent", action="store_true", help="仅在存在 FAIL 时输出")
    args = ap.parse_args()

    path = Path(args.file)
    if not path.is_file():
        print(f"错误：找不到文件 {path}", file=sys.stderr)
        return 2

    results, score = run_checks(path)
    n_fail = sum(1 for r in results if r[1] == FAIL)

    if args.json:
        print(json.dumps({
            "file": str(path), "score": round(score, 1), "failed": n_fail,
            "checks": [{"id": n.split()[0], "name": n, "status": s, "message": m, "tips": t}
                       for n, s, m, t in results],
        }, ensure_ascii=False, indent=2))
    elif not (args.silent and n_fail == 0):
        print(render(path, results, score))

    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(main())
