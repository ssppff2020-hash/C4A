#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lesson_design_template.py — 教学设计骨架生成器（确定性脚本）
隶属技能：lesson-design-assistant
用途：给定课程主题/授课对象/课时，生成一份 8 段式教学设计 Markdown 骨架，
     供 AI 或教师后续逐段填充。纯标准库，无第三方依赖。

用法示例：
    python lesson_design_template.py --topic "数据结构—栈" --audience "计算机专业大二学生" --duration 45
    python lesson_design_template.py --topic "激励理论" --audience "工商管理大三学生" --duration 90 --output lesson.md

退出码：0 成功；1 参数错误。
"""

import argparse
import datetime
import sys
from pathlib import Path


def build_skeleton(topic: str, audience: str, duration: int) -> str:
    """生成 8 段式教学设计骨架。"""
    now = datetime.datetime.now().strftime("%Y-%m-%d")
    sections = []

    sections.append(f"# 教学设计：{topic}")
    sections.append("")
    sections.append("> 本文档由 lesson-design-assistant 技能骨架生成器产出，供逐段填充完善。")
    sections.append("")
    sections.append("## 一、基本信息")
    sections.append("")
    sections.append("| 项目 | 内容 |")
    sections.append("|------|------|")
    sections.append(f"| 课程主题 | {topic} |")
    sections.append(f"| 授课对象 | {audience} |")
    sections.append(f"| 课时长度 | {duration} 分钟 |")
    sections.append(f"| 教材版本 | （待补充） |")
    sections.append(f"| 生成日期 | {now} |")
    sections.append("")
    sections.append("## 二、学情分析")
    sections.append("")
    sections.append("| 维度 | 分析 |")
    sections.append("|------|------|")
    sections.append("| 知识基础 | （学生已掌握什么？） |")
    sections.append("| 能力水平 | （学生能做什么？） |")
    sections.append("| 学习动机 | （兴趣点/痛点？） |")
    sections.append("| 差异化建议 | （学困生/学优生支持策略） |")
    sections.append("")
    sections.append("## 三、教学目标")
    sections.append("")
    sections.append("- **知识目标**：学生能够（记忆/理解动词）……")
    sections.append("- **能力目标**：学生能够（应用/分析/评价/创造动词）……")
    sections.append("- **素养目标**：学生能够（态度/价值/思政）……")
    sections.append("")
    sections.append("## 四、教学重难点")
    sections.append("")
    sections.append("- **重点**：")
    sections.append("- **难点**：")
    sections.append("- **突破策略**：")
    sections.append("")
    sections.append("## 五、教学环节设计")
    sections.append("")
    sections.append("| 环节 | 时长 | 教师活动 | 学生活动 | 设计意图 |")
    sections.append("|------|------|----------|----------|----------|")
    sections.append("| 导入 | （分钟） |  |  |  |")
    sections.append("| 新授 | （分钟） |  |  |  |")
    sections.append("| 互动 | （分钟） |  |  |  |")
    sections.append("| 应用 | （分钟） |  |  |  |")
    sections.append("| 总结 | （分钟） |  |  |  |")
    sections.append("")
    sections.append("## 六、教学方法与手段")
    sections.append("")
    sections.append("- 讲授法 / 案例教学 / 讨论法 / 任务驱动 / 信息化工具：")
    sections.append("")
    sections.append("## 七、教学评估")
    sections.append("")
    sections.append("- **过程性评估**：课堂提问 / 随堂练习 / 小组互评（观测点：）")
    sections.append("- **结果性评估**：课后作业 / 测验 / 项目（与目标对应：）")
    sections.append("")
    sections.append("## 八、课后反思与迭代")
    sections.append("")
    sections.append("1. 反思点 1：")
    sections.append("2. 反思点 2：")
    sections.append("3. 反思点 3：")
    sections.append("- 改进建议：")
    sections.append("")
    sections.append("---")
    sections.append("")
    sections.append("**自查清单**：")
    sections.append("- [ ] 8 段结构完整")
    sections.append("- [ ] 目标使用可测量动词")
    sections.append("- [ ] 每个目标至少对应 1 个教学环节")
    sections.append("- [ ] 评估覆盖全部教学目标")
    sections.append("")
    return "\n".join(sections)


def _force_utf8_stdout() -> None:
    """Windows 控制台默认 GBK，直接 print 中文骨架会乱码/报错。尽量切 UTF-8。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def main() -> int:
    _force_utf8_stdout()
    parser = argparse.ArgumentParser(
        description="生成 8 段式教学设计 Markdown 骨架"
    )
    parser.add_argument("--topic", required=True, help="课程主题（必填）")
    parser.add_argument("--audience", required=True, help="授课对象与基础（必填）")
    parser.add_argument("--duration", type=int, default=45, help="课时长度（分钟，默认 45）")
    parser.add_argument("--output", default="", help="输出文件路径（默认打印到 stdout）")
    args = parser.parse_args()

    if not args.topic.strip() or not args.audience.strip():
        print("错误：--topic 与 --audience 均为必填参数", file=sys.stderr)
        return 1
    if args.duration <= 0:
        print("错误：--duration 必须为正整数", file=sys.stderr)
        return 1

    skeleton = build_skeleton(args.topic, args.audience, args.duration)

    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(skeleton, encoding="utf-8")
        print(f"[OK] 教学设计骨架已写入：{out.resolve()}")
    else:
        print(skeleton)
    return 0


if __name__ == "__main__":
    sys.exit(main())
